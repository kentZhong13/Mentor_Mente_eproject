let cards1;
let role;
let thementeeid;
let thementorid;
const socket = io("ws://localhost:80");
socket.on("hello from server", (...args) => {
  console.log("Socket connected to server");
});
socket.emit("getcards");
socket.on("rank", (arg) => {
  console.log("Current Role: ", arg);
  role = arg;
  if (arg == "admin") {
    document.getElementById("adminToolsButton").style.display = "inline";
    document.getElementById("addPosButton").style.display = "inline";
  }
});
socket.on("receivecards", (cardinfo) => {
  handleCards(cardinfo);
});
socket.on("permupdated", (a) => {
  socket.emit("getperms", thementorid, thementeeid);
});

function handleCards(cards) {
  document.getElementById("cardsRow").innerHTML="";
  let button = document.getElementById("refreshButton");
  button.classList.remove("disabled");
  let cardsTable = document.getElementById("cardsRow");
  cards1 = cards;
  cards1.forEach((c) => {
    console.log("=====New Card=====");
    console.log(c);
    console.log(`Card Title: ${c.title}`);
    console.log(`Card Description: ${c.content}`);
    console.log(
      `Mentee Name: ${c.mentee_fname} ${c.mentee_lname} (ID: ${c.mentee_userid})`
    );
    console.log(
      `Mentor Name: ${c.mentor_fname} ${c.mentor_lname} (ID: ${c.mentor_userid})`
    );
    cardsTable.innerHTML += `<div class="col">
          <div class="card" style="width: 24em; margin: 1rem auto 1rem auto;height:15em;">
            <div class="card-body">
              <h5 class="card-title">${c.title}</h5>
              <p class="card-text">
                <p>${c.content}</p>
                
              </p>
              <a href="#" class="btn btn-primary" style="position:absolute; bottom:0;float:left; margin-bottom:1em" onclick='openCard(${JSON.stringify(
                c
              )});'>View Position</a>
              <div style="float:right; margin-top:auto; margin-bottom:0px; margin-right:2em; position:absolute; right:0; bottom:0;">
                <p style=""">Mentee: <span style="color:blue">${
                  c.mentee_fname
                } ${c.mentee_lname}</span><br>
                Mentor: <span style="color:blue">${c.mentor_fname} ${
      c.mentor_lname
    }</span></p>
                </div>
            </div>
          </div>
          </div>`;
  });
}

function getPermissions(mentorid, menteeid) {
  socket.emit("getperms", mentorid, menteeid);
}
socket.on("receiveperms", (mentorperms, menteeperms, menteeid) => {
  document.getElementById("menteeTable").innerHTML =
  "<thead class='table-dark'><tr style='text-align:center'><td colspan='2'>Mentee Permissions</td></tr></thead>";
document.getElementById("mentorTable").innerHTML =
  "<thead class='table-dark'><tr style='text-align:center'><td colspan='2'>Mentor Permissions</td></tr></thead>";
  console.log("---Mentor Permissions---");
  mentorperms.forEach(function (a) {
    console.log(a);
    if (role == "admin") {
      document.getElementById(
        "mentorTable"
      ).innerHTML += `<tr><td>${a}</td><td><button type="button" onclick="addPerm(${menteeid},'${a}')" class="btn btn-success btn-sm">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="25" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
<path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"></path>
</svg>
    </button></td></td>`;
    } else {
      document.getElementById(
        "mentorTable"
      ).innerHTML += `<tr><td></td><td>${a}</td></td>`;
    }
  });
  console.log("---Mentee Permissions---");
  menteeperms.forEach(function (a) {
    console.log(a);
    if (role == "admin") {
    document.getElementById(
      "menteeTable"
    ).innerHTML += `<tr><td>${a}</td><td><button type="button" onclick="removePerm(${menteeid},'${a}')" class="btn btn-danger btn-sm">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="25" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
  </button></td></tr>`} else {
    document.getElementById(
      "menteeTable"
    ).innerHTML += `<tr><td>${a}</td></tr>`;
  };
  });

  $("#myModal").modal("show");
});

function refreshCards() {
  let button = document.getElementById("refreshButton");
  button.classList.add("disabled");
  console.log("clear");
  // let cardsTable = document.getElementById("cardsRow");
  // cardsTable.innerHTML = "";
  socket.emit("getcards");
}

function openCard(arg) {
  document.getElementById("menteeTable").innerHTML =
    "<thead><tr><td><tr style='text-align:center'><td colspan='2'>Mentee Permissions</td></tr></thead>";
  document.getElementById("mentorTable").innerHTML =
    "<thead><tr style='text-align:center'><td colspan='2'>Mentor Permissions</td></tr></thead>";
  console.log(arg);
  thementorid= arg.mentor_userid
  thementeeid = arg.mentee_userid
  getPermissions(arg.mentor_userid, arg.mentee_userid);
  document.getElementById("modalTitle").innerHTML = arg.title;
}

function newCardModal(arg) {
  // $("#myModal2").modal("show");
  socket.emit("getusers");
  document.getElementById("menteelist").innerHTML = "<option value=0>None</option>";
  document.getElementById("mentorlist").innerHTML = "<option value=0>None</option>";
}
socket.on("sendusers", (user) => {
  let menteelist = document.getElementById("menteelist");
  let mentorlist = document.getElementById("mentorlist");
  user.forEach(function(a) {
    if (a.rank == 1) {
      menteelist.innerHTML += `<option value=${a.userid}>${a.fname} ${a.lname}</option>`
    } else if (a.rank > 1) {
      mentorlist.innerHTML += `<option value=${a.userid}>${a.fname} ${a.lname}</option>`
    }
  })
  $("#myModal2").modal("show");
})

function addCard() {
  let a = document.getElementById("Title").value;
  let b = document.getElementById("menteelist").value;
  let c = document.getElementById("mentorlist").value;
  let d = document.getElementById("description").value;
  socket.emit("addcard", a, b, c, d);
}
socket.on("cardadded", (a) => {
  refreshCards();
  $("#myModal2").modal("hide")
})

function addPerm(menteeid, perm) {
  console.log("add perm");
  socket.emit("addperm", menteeid, perm)
  
}

function removePerm(menteeid, perm) {
  console.log("remove perm");
  socket.emit("removeperm", menteeid, perm)
}
