const mysql = require("mysql");
const express = require("express");
const session = require("express-session");
const path = require("path");
const http = require("http");
const async = require("async");

const app = express();
// server??
const server = http.createServer(app);

// Setup SOCKETS
const { Server } = require("socket.io");
const { Socket } = require("dgram");
const io = new Server(server);

app.use(
  session({
    secret: "secret",
    resave: true,
    saveUninitialized: true,
  })
);
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);
// app.use(express.static(path.join(__dirname, "static")));
// app.use(express.static('/'));
app.use(express.static(__dirname + "/")); //Serves resources from current directory

// http://localhost:80/
app.get("/", function (request, response) {
  console.log("user requested index");
  if (request.session.loggedin) {
    // redirect user to home if they are already logged in
    response.redirect("/home");
  } else {
    // Not logged in, send them login page
    response.sendFile(path.join(__dirname + "/login.html"));
    io.once("connection", (socket) => {
      console.log(socket.id);
      socket.emit("hello from server", "index");
      socket.on("hello from client", (arg) => {
        console.log("client connected to server");
        console.log(request.session.username);
      });
    });
  }
});

// http://localhost/auth
app.post("/auth", function (request, response) {
  // Capture the input fields
  console.log("user requested auth");
  let username = request.body.username;
  let password = request.body.password;
  // Ensure the input fields exists and are not empty
  if (username && password) {
    const connection = mysql.createConnection({
      host: "107.180.1.16",
      database: "440fall20226",
      user: "440fall20226",
      password: "440fall20226",
    });
    // Execute SQL query that'll select the account from the database based on the specified username and password
    connection.query(
      "SELECT * FROM accounts WHERE username = ? AND password = ?",
      [username, password],
      function (error, results, fields) {
        // If there is an issue with the query, output the error
        if (error) throw error;
        // If the account exists
        if (results.length > 0) {
          // Authenticate the user
          request.session.loggedin = true;
          request.session.username = username;
          // Redirect to home page
          response.redirect("/home");
        } else {
          response.send("Incorrect Username and/or Password!");
        }
        response.end();
      }
    );
    connection.end();
  } else {
    response.send("Please enter Username and Password!");
    response.end();
  }
});

// http://localhost:80/home
app.get("/home", function (request, response) {
  let role;
  console.log("user requested home");
  // If the user is loggedin
  if (request.session.loggedin) {
    // Send home page
    // console.log(request);
    console.log(request.session.username);
    response.sendFile(path.join(__dirname, "/home.html"));
    io.once("connection", (socket) => {
      let userid;
      console.log(socket.id);
      socket.emit("hello from server");
      socket.on("hello from client", (arg) => {
        console.log("client connected to server");
        console.log(request.session.username);
      });
      // Client sends getcards socket.emit when it loads the home.html page
      socket.on("getcards", (arg) => {
        // sql stuff to determine rank and information sent
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // Execute SQL query
        connection.query(
          `select * from accounts where username = "${request.session.username}"`,
          // Function that processes result
          function (error, results, fields) {
            // If there is an issue with the query, output the error
            if (error) {
              // end connection to SQL server
              connection.end();
              throw error;
            }
            // If the account exists, and there is only ONE result (no duplicate usernames)
            if ((results.length = 1)) {
              // If the rank of the result is >= to 2, they are an admin (mentor and managers are admins)
              if (results[0].rank >= 2) {
                request.session.role = "admin";
                role = "admin";
              } else if ((results[0].rank = 1)) {
                request.session.role = "mentee";
                role = "mentee";
              } else {
                request.session.role = "none";
                role = "none";
              }
              userid = results.userid;
              // console.log(results[0])
              // Sends the role of the user to the client, USE THIS IN AN IF STATEMENT TO SEND CERTAIN INFO THAT WILL PROCESS THE CARDS
              socket.emit("rank", role);
              console.log(request.session);
              request.session.save();
            } else {
              console.log("No user found, or multiple found");
            }
          }
        );
        // works????
        // connection.query(
        //   `select * from cards`,
        //   function (err, result) {
        //     // if there are no errors, then loop through all the recorsd (if any)
        //     if (err) {
        //       // this will propapage or "throw" the error to the calling method
        //       console.log("Error processing result");
        //       // end connection to SQL server
        //       connection.end();
        //       throw err;
        //     } else {
        //       // there were no errors
        //       // how many rows were returned
        //       console.log(`There were ${result.length} rows returned`);
        //       // invoke foreach and supply callback function which can handle one record
        //       async.each(result, function (record) {
        //         connection.query(
        //           `select fname, lname from accounts where userid=${record.mentorid}`,
        //           function (err, result) {
        //             if (err) {
        //               throw err;
        //             }
        //             console.log(result);
        //           }
        //         );
        //       });

        //     } //else
        //   },
        //   function (err) {
        //     connection.end();
        //   } //ending processResult);
        // );
        // connection.query(`select card.title, card.content, mentee.fname, mentee.lname, mentor.fname, mentor.lname from cards as card inner join accounts as mentee on card.menteeid = mentee.userid inner join accounts as mentor on card.mentorid = mentor.userid`, function (error, results, fields) {
        //   console.log(results);
        // })

        // connection.query(`select card.title, card.content, mentee.fname as mentee_fname, mentee.lname as mentee_lname, mentor.fname as mentor_fname, mentor.lname as mentor_lname, json_query((select permission as mentee_permission from permissions p where p.userid=mentee.userid)) as mentee_permissions from cards card join accounts mentee on mentee.userid = card.menteeid join accounts mentor on  mentor.userid = card.mentorid;`, function (error, results, fields) {
        connection.query(
          `select card.id, card.title, card.content, mentee.fname as mentee_fname, mentee.lname as mentee_lname, mentor.fname as mentor_fname, mentor.lname as mentor_lname, mentee.userid as mentee_userid, mentor.userid as mentor_userid from cards card join accounts mentee on mentee.userid = card.menteeid join accounts mentor on  mentor.userid = card.mentorid;`,
          function (error, results, fields) {
            if (error) {
              // end connection to SQL server
              throw error;
            }
            // io.emit("receivecards", results);
            socket.emit("receivecards", results);
            results.forEach(function (record) {
              console.log(record);
            });
          }
        );
        connection.end();

        // function processRecord(record) {
        //   console.log(record);
        //   connection.query(`select * from accounts`, function (err, result) {
        //     // if (err){throw err}
        //     console.log(result);
        //   });
        // }

        // idk if this actually does anything
        socket.on("disconnect", () => {
          socket.removeAllListeners();
        });
      });

      socket.on("getperms", (mentorid, menteeid) => {
        menteePermissions = new Array();
        mentorPermissions = new Array();
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        console.log(mentorid);
        console.log(menteeid);
        // to-do: use where clause for user-id with mentorid and menteeid args
        connection.query(
          `select userid, permission from permissions where userid=${menteeid} or userid=${mentorid};`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            results.forEach(function (record) {
              // console.log(record)
              if (record.userid == menteeid) {
                menteePermissions.push(record.permission);
              } else if (record.userid == mentorid) {
                mentorPermissions.push(record.permission);
              }
            });
            console.log(menteePermissions);
            console.log(mentorPermissions);
            socket.emit("receiveperms", mentorPermissions, menteePermissions, menteeid);
          }
        );

        connection.end();
      });

      socket.on("getusers", (args) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `select userid, fname, lname, rank from accounts;`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            // io.emit("sendusers", results);
            socket.emit("sendusers", results);
          }
        );

        connection.end();
      });


      socket.on("addperm", (menteeid, perm) => {
        console.log(menteeid, perm);
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        if (request.session.role == "admin") {
          connection.query(
            `insert ignore into permissions (userid, permission) values (${menteeid}, "${perm}")`,
            function (err, results) {
              if (err) {
                // end connection to SQL server
                throw err;
              }
              socket.emit("permupdated");
              // socket.emit("receiveperms", mentorPermissions, menteePermissions);
            }
          );
        } else {
          console.log("no perms");
        }
        connection.end();
      })
      socket.on("removeperm", (menteeid, perm) => {
        console.log(menteeid, perm);
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        if (request.session.role == "admin") {
          connection.query(
            `delete from permissions where userid = ${menteeid} and permission = "${perm}";`,
            function (err, results) {
              if (err) {
                // end connection to SQL server
                throw err;
              }
              socket.emit("permupdated");
              // socket.emit("receiveperms", mentorPermissions, menteePermissions);
            }
          );
        } else {
          console.log("no perms");
        }
        connection.end();
        
      })

      socket.on("addcard", (title, menteeid, mentorid, description) => {
        console.log("add card");
        console.log(request.session.role);
        console.log(title, menteeid, mentorid, description);
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        if (request.session.role == "admin") {
          connection.query(
            `insert into cards (title, menteeid, mentorid, content) values ("${title}", ${menteeid}, ${mentorid}, "${description}")`,
            function (err, results) {
              if (err) {
                // end connection to SQL server
                throw err;
              }
              io.emit("cardadded");
              // socket.emit("cardadded");
            }
          );
        } else {
          console.log("no perms");
        }

        connection.end();
      });
    });

    // Send home page
    // response.send("Welcome back, " + request.session.username + "!");
  } else {
    // Not logged in
    response.redirect("/");
    // response.send("Please login to view this page!");
  }
  //   doesn't serve webpage if response.end()
  //   response.end();
});

app.get("/logout", function (request, response) {
  if (request.session.loggedin) {
    request.session.destroy((err) => {
      if (err) {
        response.status(400).send("Unable to log out");
      } else {
        response.redirect("/");
      }
    });
  } else {
    response.end();
  }
});

app.get("/admin", function (request, response) {
  if (request.session.loggedin && request.session.role == "admin") {
    console.log(request.session);
    response.sendFile(path.join(__dirname, "/admin.html"));

    io.once("connection", (socket) => {
      socket.on("getaccounts", (args) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `select * from accounts;`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            socket.emit("sendaccounts", results);
          }
        );

        connection.end();
      });
      socket.on("adduser", (a, b, c, d, e) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `insert into accounts (username, password, fname, lname, rank) values ("${a}", "${b}", "${c}", "${d}", ${e});`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            socket.emit("accountsupdated");
            // socket.emit("sendaccounts", results);
          }
        );
        connection.end();
      });
      socket.on("removeuser", (a) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `delete from accounts where userid = ${a}`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            socket.emit("accountsupdated");
            // socket.emit("sendaccounts", results);
          }
        );
        
        connection.end();
      });
      socket.on("getcards", (a) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `select * from cards;`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            console.log('sending cards');
            socket.emit("sendcards", results);
            // io.socket.emit("sendcards", results);
            // socket.emit("sendaccounts", results);
          }
        );
        connection.end();
      });
      socket.on("removecard", (a) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `delete from cards where id = ${a};`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            socket.emit("cardsupdated", results);
            // socket.emit("sendaccounts", results);
          }
        );
        connection.end();
      })
      socket.on("getusers", (a) => {
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        // SQL query to select all from accounts
        connection.query(
          `select userid, fname, lname, rank from accounts;`,
          function (err, results) {
            if (err) {
              // end connection to SQL server
              throw err;
            }
            // console.log(results)
            socket.emit("sendusers", results)
          }
        );

        connection.end();
      });

      socket.on("editcard", (title, menteeid, mentorid, description, cardid) => {
        console.log("edit card");
        console.log(title, menteeid, mentorid, description);
        const connection = mysql.createConnection({
          host: "107.180.1.16",
          database: "440fall20226",
          user: "440fall20226",
          password: "440fall20226",
        });
        if (request.session.role == "admin") {
          connection.query(
            `update cards set title="${title}", menteeid=${menteeid}, mentorid=${mentorid}, content="${description}" where id=${cardid}`,
            function (err, results) {
              if (err) {
                // end connection to SQL server
                throw err;
              }
              // socket.emit("cardedited");
            }
          );
        } else {
          console.log("no perms");
        }

        connection.end();
      });
    });
  } else {
    response.redirect("/");
  }
});

function processRecord(record) {
  console.log(record);
  const connection = mysql.createConnection({
    host: "107.180.1.16",
    database: "440fall20226",
    user: "440fall20226",
    password: "440fall20226",
  });
  connection.query(
    `select fname, lname from accounts where userid=${record.mentorid}`,
    function (err, result) {
      // if (err){throw err}
      console.log(result);
    }
  );
  connection.end();
}

// app.listen(80);
// console.log("Server listening on port 80");
server.listen(80, () => {
  console.log("listening on 80");
});
